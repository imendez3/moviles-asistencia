# moviles-asistencia
Sistema de Control de Asistencia de Alumnos para Android
