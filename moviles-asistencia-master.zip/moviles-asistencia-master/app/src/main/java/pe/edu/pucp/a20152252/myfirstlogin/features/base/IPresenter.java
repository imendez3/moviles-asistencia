package pe.edu.pucp.a20152252.myfirstlogin.features.base;

public interface IPresenter {
    void onDestroy();
}
