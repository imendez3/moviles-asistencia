package pe.edu.pucp.a20152252.myfirstlogin.features.base;

import android.content.Context;

public interface IView {
    Context getContext();

    void onDestroy();
}
