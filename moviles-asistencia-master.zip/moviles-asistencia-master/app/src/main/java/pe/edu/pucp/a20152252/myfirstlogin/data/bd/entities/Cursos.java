package pe.edu.pucp.a20152252.myfirstlogin.data.bd.entities;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "CURSOS")
public class Cursos {
    @PrimaryKey
    @ColumnInfo(name = "CURSO_ID")
    private int cursoId;

    @ColumnInfo(name = "NOMBRE")
    private String nombre;

    @ColumnInfo(name = "HORARIO")
    private int horario;

    public int getCursoId() {
        return cursoId;
    }

    public String getNombre() {
        return nombre;
    }

    public int getHorario() {
        return horario;
    }

    public Cursos(int cursoId, String nombre, int horario) {
        this.cursoId = cursoId;
        this.nombre = nombre;
        this.horario = horario;
    }
}
