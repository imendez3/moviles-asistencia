package pe.edu.pucp.a20152252.myfirstlogin.data.bd.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import pe.edu.pucp.a20152252.myfirstlogin.data.bd.entities.Clases;
import pe.edu.pucp.a20152252.myfirstlogin.data.bd.entities.User;

@Dao
public interface ClasesDao {

    @Query("SELECT * FROM CLASES WHERE Clase_ID = :claseId LIMIT 1")
    Clases findById(int claseId);

    @Query("SELECT * FROM CLASES WHERE FECHA = :fecha LIMIT 1")
    Clases findByFecha(String fecha);

    @Query("SELECT * FROM CLASES WHERE CURSO_ID = :cursoId LIMIT 1")
    Clases findByCursoId(int cursoId);

    @Insert
    void insert(Clases clases);

    @Delete
    void delete(Clases clases);
}
