package pe.edu.pucp.a20152252.myfirstlogin.data.bd.entities;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "CLASES")
public class Clases {
    @PrimaryKey
    @ColumnInfo(name = "Clase_ID")
    private int claseId;

    @ColumnInfo(name = "CURSO_ID")
    private int cursoId;

    @ColumnInfo(name = "NOMBRE")
    private String nombre;

    @ColumnInfo(name = "HORARIO")
    private int horario;

    @ColumnInfo(name = "AULA")
    private String aula;

    @ColumnInfo(name = "HORA_INICIO")
    private String horaInicio;

    @ColumnInfo(name = "HORA_FIN")
    private String horaFin;

    @ColumnInfo(name = "TIPO_CLASE")
    private int tipoClase;

    @ColumnInfo(name = "ASISTENACIA")
    private int asistencia;

    @ColumnInfo(name = "POS_X")
    private int posX;

    @ColumnInfo(name = "POS_Y")
    private int posY;

    @ColumnInfo(name = "FECHA")
    private String fecha;

    public int getClaseId() {
        return claseId;
    }


    public int getHorario() {
        return horario;
    }

    public int getCursoId() {
        return cursoId;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAula() {
        return aula;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public int getTipoClase() {
        return tipoClase;
    }

    public int getAsistencia() {
        return asistencia;
    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    public String getFecha() {
        return fecha;
    }

    public Clases(int claseId, int cursoId, String nombre, int horario, String aula, String horaInicio, String horaFin, int tipoClase, int asistencia, int posX, int posY, String fecha) {
        this.claseId = claseId;
        this.cursoId = cursoId;
        this.nombre = nombre;
        this.horario = horario;
        this.aula = aula;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.tipoClase = tipoClase;
        this.asistencia = asistencia;
        this.posX = posX;
        this.posY = posY;
        this.fecha = fecha;
    }
}
