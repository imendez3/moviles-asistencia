package pe.edu.pucp.a20152252.myfirstlogin.data.bd.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import pe.edu.pucp.a20152252.myfirstlogin.data.bd.entities.Cursos;

@Dao
public interface CursosDao {

    @Query("SELECT * FROM CURSOS WHERE CURSO_ID = :cursoId LIMIT 1")
    Cursos findById(int cursoId);

    @Insert
    void insert(Cursos cursos);

    @Delete
    void delete(Cursos cursos);
}
